import { Injectable } from '@angular/core';


@Injectable()
export class Globals {
  hasSession = false;
  sessionObj: any = {};
  defaultLang: string = 'en';
}
